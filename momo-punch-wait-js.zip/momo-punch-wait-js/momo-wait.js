/* ==========================================================
   momo 當機等候頁 — Punch edition（純 JavaScript 版）
   一個檔案完成：注入樣式 → 建立畫面 → 自動重試 → 呼吸提示
   用法：<div id="app"></div> 之後引入此檔案即可
   ========================================================== */
(function () {
  'use strict';

  /* ---------- 設定區 ---------- */
  const CONFIG = {
    mountId: 'app',
    imageSrc: 'images/punch.jpg',
    retrySeconds: [30, 45, 60, 90, 120], // 第 1、2、3… 次自動重試前的等待秒數
    storageKey: 'momoWaitRetries',
    breathPhaseMs: 4000,                 // 吸氣／吐氣各 4 秒（須等於 CSS --breath 的一半）
    text: {
      brand: 'momo購物網',
      title: ['現在逛的人很多，', '請等我們一下'],
      lead: '首頁暫時打不開，系統正在排隊處理。你的購物車、訂單和折價券都還在，不需要重新下單。',
      caption: '小猴 Punch 抱著玩偶，陪你一起等。',
      alt: '一隻小日本獼猴 Punch 閉著眼睛，靠在橘色猩猩玩偶身上休息',
      safe: ['購物車商品已保留', '訂單與付款紀錄不受影響', '請不要重複下單或重複付款'],
      help: '超過 5 分鐘還是打不開，可以改用 momo APP，或稍後再試。',
      reload: '立即重新載入',
      pause: '暫停自動載入',
      resume: '繼續自動載入',
      inhale: '吸氣⋯⋯',
      exhale: '吐氣⋯⋯',
      breathHint: '跟 Punch 一起慢慢呼吸',
      gaveUp: '已多次嘗試。請休息一下，準備好再按「立即重新載入」。'
    }
  };

  /* ---------- 樣式 ---------- */
  const CSS = `
:root{
  --blush:#FFF1E8; --plush:#F2B27E; --plush-deep:#E58A44;
  --momo:#D4105F; --momo-dark:#B40B4E;
  --ink:#36261F; --fur:#6B5F58; --line:#EBCDB8;
  --font-title:"Huninn","Noto Sans TC","PingFang TC","Microsoft JhengHei",sans-serif;
  --font-body:"Noto Sans TC","PingFang TC","Microsoft JhengHei",system-ui,sans-serif;
  --breath:${CONFIG.breathPhaseMs * 2}ms;
}
*,*::before,*::after{box-sizing:border-box}
html,body{height:100%}
body{margin:0;background:var(--blush);color:var(--ink);font-family:var(--font-body);font-size:1rem;line-height:1.8;-webkit-font-smoothing:antialiased}

.wait{min-height:100%;display:grid;grid-template-columns:minmax(280px,380px) minmax(0,520px);gap:clamp(2rem,6vw,5.5rem);align-items:center;justify-content:center;padding:clamp(1.5rem,5vw,4rem)}

.punch{margin:0}
.punch__frame{border-radius:999px 999px 28px 28px;background:var(--plush);padding:14px;box-shadow:0 0 0 1px var(--line);overflow:hidden}
.punch__frame img{display:block;width:100%;height:auto;aspect-ratio:334/598;object-fit:cover;border-radius:999px 999px 18px 18px;transform-origin:50% 70%;animation:breathe var(--breath) ease-in-out infinite}
.punch__caption{margin-top:.9rem;font-size:.9rem;color:var(--fur);text-align:center}

.msg{max-width:34rem}
.msg__brand{margin:0 0 .75rem;font-family:var(--font-title);font-size:1.15rem;color:var(--momo)}
.msg__title{margin:0 0 1rem;font-family:var(--font-title);font-weight:400;font-size:clamp(2rem,4.6vw,3.1rem);line-height:1.25;letter-spacing:.02em}
.msg__lead{margin:0 0 1.75rem;max-width:30em}

.retry{padding:1.25rem 0 1.5rem;border-top:1px solid var(--line)}
.retry__status{margin:0 0 .6rem;font-size:1.05rem}
.retry__status b{font-variant-numeric:tabular-nums;color:var(--momo)}
.retry__bar{height:6px;border-radius:999px;background:var(--line);overflow:hidden}
.retry__bar span{display:block;height:100%;width:0;background:var(--momo);border-radius:inherit;transition:width 1s linear}
.retry__actions{display:flex;flex-wrap:wrap;gap:.75rem;margin-top:1.1rem}

.btn{font:inherit;font-weight:700;font-size:1.05rem;line-height:1;min-height:48px;padding:0 1.4rem;border-radius:999px;border:2px solid transparent;cursor:pointer;transition:background-color .15s,color .15s,border-color .15s}
.btn[hidden]{display:none}
.btn--primary{background:var(--momo);color:#fff}
.btn--primary:hover{background:var(--momo-dark)}
.btn--ghost{background:transparent;color:var(--ink);border-color:var(--line)}
.btn--ghost:hover{border-color:var(--ink)}
.btn--ghost[aria-pressed="true"]{background:var(--ink);color:var(--blush);border-color:var(--ink)}
.btn:focus-visible{outline:3px solid var(--ink);outline-offset:3px}

.safe{list-style:none;margin:0;padding:1.25rem 0;border-top:1px solid var(--line);display:grid;gap:.35rem}
.safe li{position:relative;padding-left:1.7rem}
.safe li::before{content:"";position:absolute;left:.2rem;top:.62em;width:.5rem;height:.9rem;border:solid var(--plush-deep);border-width:0 3px 3px 0;transform:translateY(-50%) rotate(45deg)}

.breath{display:flex;align-items:center;gap:.85rem;padding:1.1rem 0;border-top:1px solid var(--line);color:var(--fur);font-size:.95rem}
.breath__dot{flex:none;width:22px;height:22px;border-radius:50%;background:var(--plush);animation:dot var(--breath) ease-in-out infinite}
.breath__label{min-width:4.2em;font-family:var(--font-title);color:var(--ink);font-size:1.1rem}
.msg__help{margin:.4rem 0 0;font-size:.9rem;color:var(--fur)}

@keyframes breathe{0%,100%{transform:scale(1)}50%{transform:scale(1.025)}}
@keyframes dot{0%,100%{transform:scale(1);box-shadow:0 0 0 0 rgba(229,138,68,.35)}50%{transform:scale(1.5);box-shadow:0 0 0 10px rgba(229,138,68,0)}}

@media (prefers-reduced-motion:reduce){.punch__frame img,.breath__dot{animation:none}.retry__bar span{transition:none}}

@media (max-width:820px){
  .wait{grid-template-columns:minmax(0,1fr);justify-items:center;gap:1.75rem;padding:1.5rem 1.25rem 2.5rem;align-items:start}
  .punch{width:min(64vw,260px)}
  .msg{width:100%}
  .msg__title{font-size:clamp(1.8rem,7.5vw,2.4rem)}
  .btn{flex:1 1 100%}
}`;

  function injectAssets() {
    const font = document.createElement('link');
    font.rel = 'stylesheet';
    font.href = 'https://fonts.googleapis.com/css2?family=Huninn&display=swap'; // 載入失敗會自動用備用字體
    document.head.appendChild(font);

    const style = document.createElement('style');
    style.textContent = CSS;
    document.head.appendChild(style);
  }

  /* ---------- 建立 DOM 的小工具 ---------- */
  function h(tag, attrs, ...children) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === false || v == null) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const c of children.flat()) {
      el.append(c instanceof Node ? c : document.createTextNode(c));
    }
    return el;
  }

  /* ---------- 建立畫面 ---------- */
  function buildView() {
    const t = CONFIG.text;

    const countEl = h('b', { text: '0' });
    const statusEl = h('p', { class: 'retry__status' });
    const barFill = h('span');
    const reloadBtn = h('button', { type: 'button', class: 'btn btn--primary', text: t.reload });
    const pauseBtn = h('button', { type: 'button', class: 'btn btn--ghost', 'aria-pressed': 'false', text: t.pause });
    const breathLabel = h('span', { class: 'breath__label', text: t.inhale });

    const root = h('main', { class: 'wait' },
      h('figure', { class: 'punch' },
        h('div', { class: 'punch__frame' },
          h('img', { src: CONFIG.imageSrc, width: 334, height: 598, alt: t.alt })
        ),
        h('figcaption', { class: 'punch__caption', text: t.caption })
      ),
      h('section', { class: 'msg', 'aria-labelledby': 'title' },
        h('p', { class: 'msg__brand', text: t.brand }),
        h('h1', { id: 'title', class: 'msg__title' }, t.title[0], h('br'), t.title[1]),
        h('p', { class: 'msg__lead', text: t.lead }),
        h('div', { class: 'retry', role: 'group', 'aria-label': '自動重新載入' },
          statusEl,
          h('div', { class: 'retry__bar', 'aria-hidden': 'true' }, barFill),
          h('div', { class: 'retry__actions' }, reloadBtn, pauseBtn)
        ),
        h('ul', { class: 'safe' }, t.safe.map(s => h('li', { text: s }))),
        h('div', { class: 'breath', 'aria-hidden': 'true' },
          h('span', { class: 'breath__dot' }),
          breathLabel,
          h('span', { text: t.breathHint })
        ),
        h('p', { class: 'msg__help', text: t.help })
      )
    );

    document.getElementById(CONFIG.mountId).replaceChildren(root);
    return { countEl, statusEl, barFill, reloadBtn, pauseBtn, breathLabel };
  }

  /* ---------- 重試次數（sessionStorage 不可用時退回 0） ---------- */
  const store = {
    get() {
      try { return parseInt(sessionStorage.getItem(CONFIG.storageKey), 10) || 0; }
      catch (e) { return 0; }
    },
    set(n) {
      try { sessionStorage.setItem(CONFIG.storageKey, String(n)); } catch (e) {}
    }
  };

  /* ---------- 自動重新載入 ---------- */
  function setupRetry(ui) {
    const t = CONFIG.text;
    const retries = store.get();
    const steps = CONFIG.retrySeconds;

    // 狀態文字：「將在 N 秒後自動重新載入」/「已暫停（剩 N 秒）」
    function setStatus(prefix, suffix) {
      ui.statusEl.replaceChildren(prefix, ui.countEl, suffix);
    }

    // 多次失敗：停止自動載入，改手動
    if (retries >= steps.length) {
      ui.statusEl.textContent = t.gaveUp;
      ui.pauseBtn.hidden = true;
      ui.reloadBtn.addEventListener('click', manualReload);
      return;
    }

    const total = steps[retries];
    let left = total;
    let paused = false;

    function render() {
      ui.countEl.textContent = left;
      ui.barFill.style.width = ((total - left) / total * 100) + '%';
    }

    function manualReload() {
      store.set(0); // 使用者主動重試，重置退避
      location.reload();
    }

    setStatus('將在 ', ' 秒後自動重新載入');
    render();

    setInterval(() => {
      if (paused) return;
      left -= 1;
      render();
      if (left <= 0) {
        store.set(retries + 1);
        location.reload();
      }
    }, 1000);

    ui.reloadBtn.addEventListener('click', manualReload);

    ui.pauseBtn.addEventListener('click', () => {
      paused = !paused;
      ui.pauseBtn.setAttribute('aria-pressed', String(paused));
      ui.pauseBtn.textContent = paused ? t.resume : t.pause;
      if (paused) setStatus('已暫停自動載入（剩 ', ' 秒）');
      else setStatus('將在 ', ' 秒後自動重新載入');
    });
  }

  /* ---------- 呼吸文字 ---------- */
  function setupBreath(ui) {
    let inhale = true;
    setInterval(() => {
      inhale = !inhale;
      ui.breathLabel.textContent = inhale ? CONFIG.text.inhale : CONFIG.text.exhale;
    }, CONFIG.breathPhaseMs);
  }

  /* ---------- 啟動 ---------- */
  function init() {
    injectAssets();
    const ui = buildView();
    setupRetry(ui);
    setupBreath(ui);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
